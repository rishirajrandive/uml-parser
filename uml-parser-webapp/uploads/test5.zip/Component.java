
public interface Component {

	public String operation();

}
